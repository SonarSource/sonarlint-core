#
# Copyright (c) 2022 Jean-Baptiste Lièvremont
#

def say_hello(to_whom='World'):
    print(f'Hello, {to_whom}!')
