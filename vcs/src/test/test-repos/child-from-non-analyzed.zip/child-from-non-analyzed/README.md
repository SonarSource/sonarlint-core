# sonarlint-branch-sync-tests
Repository for the validation of SonarLint's branch synchronization in connected mode

[![SonarCloud](https://sonarcloud.io/images/project_badges/sonarcloud-white.svg)](https://sonarcloud.io/summary/new_code?id=jblievremont_sonarlint-branch-sync-tests)
